import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SmartbotServiceService {

  apiURL = 'http://localhost:5000/SmartBotAPI';
  constructor(private http : HttpClient) {}

  public getResponse(query: string) : Observable<JSON>
  {
    let params = new HttpParams().set('query', query);
    return this.http.get<JSON>(this.apiURL, {params})
    }
}
